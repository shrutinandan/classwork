package com.cybage.service;

import java.util.List;

import com.cybage.model.Category;


public interface HomeService 
{
	
	List<Category> getCategories();
	Integer saveCategory(Category category);
}
