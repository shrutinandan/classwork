package com.cybage.dao;

import java.util.List;

import com.cybage.model.Category;


public interface HomeDao
{
	
	List<Category> getCategories();
	Integer saveCategory(Category category);
}
